#MATEUS TEIXEIRA MAGALHÃƒES - UFJF - PGMC
#github repository: https://github.com/mateus96mt/InterpolationSchemes.git

import numpy as np
import math
import tools
import upwind_schemes as SCHEMES
import advection_diffusion_solver_1D as solver


def calculateError(exata, y_numerica, nx, tipo = 2):
    
    sum_num = 0.0
    sum_dem = 0.0
    max_diff_exata_num = 0.0
    max_exata = 0.0
    
    for i in range(nx):
        
        if tipo == 1:
            
            sum_num = sum_num + abs(exata[i] - y_numerica[i])
            sum_dem = sum_dem + abs(exata[i])
            
        if tipo == 2:
            
            sum_num = sum_num + ((exata[i] - y_numerica[i])**2)
            sum_dem = sum_dem + (exata[i]**2)
        
        if abs(exata[i] - y_numerica[i]) > max_diff_exata_num:
            
            max_diff_exata_num = abs(exata[i] - y_numerica[i])
            
        if abs(exata[i])>max_exata:
            
            max_exata = abs(exata[i])
            
    
    if tipo == 1:
        
        return sum_num/sum_dem

    if tipo == 2:
        
        return np.sqrt(sum_num/sum_dem)
    
    if tipo == 3:
        
        return max_diff_exata_num/max_exata
    

#-----------------------------------INITIAL CONDITIONS------------------------

#INICIAL CONDITION FOR LINEAR-ADVECTION, (DISSERTACAO RAFAEL, CASOS 1, 2 e 3)
def u_0(x, case = 1):
    
    if case == 1:
    
        if x>=0 and x<0.2:
            
            return np.exp(-math.log(((x-0.15)/0.05)**2, 50))
        
        if x>0.3 and x<0.4:
            
            return 1
        
        if x>0.5 and x<0.55:
            
            return 20.0*x-10.0
        
        if x>=0.55 and x<0.66:
            
            return -20*x + 12
        
        if x>0.7 and x<0.8:
            
            return math.sqrt(1 - (((x-0.75)/0.05)**2))
        
        return 0

    if case == 2:
        
        if x>=0 and x<=0.2:
            
            return 1
        
        if x>0.2 and x<=0.4:
            
            return 4*x-0.6
        
        if x>0.4 and x<=0.6:
            
            return -4*x + 2.6
        
        if x>0.6 and x<=0.8:
            
            return 1
        
        return 0
    
    if case == 3:
        
        if x>=-1 and x<=-1/3:
            
            return -x*np.sin(3*np.pi*(x**2)/2.0)
            
        if x>-1/3 and x<1/3:
            
            return abs(np.sin(2*np.pi*x))
        
        if x>=1/3 and x<=1:
            
            return 2*x - 1.0 - (1/6)*np.sin(3*np.pi*x)
        
        return 0
        
def initial_cond_func_Burges(x):
    
    return np.sin(2 * math.pi * x)
            

def initial_cond_func_Boundary_Layer(x):
    
    return 0.0
            
def initial_cond_func_Linear_Advection(x, case = 1):
    
    return  u_0(x, case = case)

#-----------------------------------INITIAL CONDITIONS------------------------



#-----------------------------------ANALITIC SOLUTIONS------------------------

def analitic_boundary_layer_equation(x, v):
    
    return (1 - np.exp(x / v)) / (1 - np.exp(1 / v))


def analitic_linear_advection(x, u_0, t, a, case = 1):
    
    return u_0(x - a*t, case)

#-----------------------------------------------------------------------------

def schemes_comparation_boundary_layer_equation_test():
    
    tools.clear()
    
    ymin = -0.1
    ymax = 1.1
    
    alpha = 2.0
    
    beta = 2.0
    
    gamma = 12.0
    
    lam = 95.0
    
    params = [alpha, beta, gamma, lam]
    
#    schemes = [[SCHEMES.TOPUS, 'TOPUS alpha'],
#               [SCHEMES.FSFL, 'FSFL beta'],
#               [SCHEMES.SDPUS_C1, 'SDPUS-C1 gamma'],
#               [SCHEMES.EPUS, 'EPUS lambda']]
#    schemes = [[SCHEMES.TOPUS, 'TOPUS alpha']]
#    schemes = [[SCHEMES.FSFL, 'FSFL beta']]
#    schemes = [[SCHEMES.SDPUS_C1, 'SDPUS-C1 gamma']]
    schemes = [[SCHEMES.EPUS, 'EPUS lambda']]
        
    domx = [0, 1]
    
    domt = [0, 0.5]
 
    PATH = 'taxas'
    
    ns = [80, 160, 320, 640]
    markers = ['x', '*', '+', '.']    

    t = domt[-1]
    
    v= 0.02
    
    time_precision = 4
                
    time_string = "{:." + str(time_precision) + "f}"
    
    for scheme_index in range(len(schemes)):
        
        h_vet = []
    
        e1_vet = []
        e2_vet = []
        e3_vet = []
        
        tools.clear()
        
        scheme = schemes[scheme_index]
                
        custom_path = PATH + '_' + scheme[0].__name__ + '/'
        
        print("\n\n\n------------------------------------" + scheme[0].__name__  + "------------------------------------\n\n")
        print("N           e1           o1           e2           o2           e3          o3\n")
        
        fileName = custom_path + 'result'\
                    + '.png'
                    
        title = 'tempo = ' + str(t)
        
        x_axes = np.linspace(domx[0], domx[-1], 640)
            
        analitic = [analitic_boundary_layer_equation(x_axes[i], v)\
                    for i in range(640)]
        
        tools.save_fig(x_axes, analitic, fileName, 'analitica', 'analitica_v=' + str(v),\
                marker = None,\
                xlabel = 'x', ylabel = 'y',\
                clean_plot = False, margin = 0.1, ymin = ymin, ymax = ymax)
        
        index = 0
        for nx in ns:
            
            initial_cond_func = lambda x: initial_cond_func_Boundary_Layer(x)
                           
            param = params[scheme_index]
            
            marker = markers[index]
            
            
            SCHEME = scheme[0]
            
            SCHEME_LABEL = 'N=' + str(nx)
                        
            dx = (domx[-1] - domx[0]) / (nx-1)

            dt = 0.01 / float(nx)
            
            cfl = dt / dx
            
            x_axes = [domx[0] + i*dx for i in range(nx)]
            
            analitic = [analitic_boundary_layer_equation(x_axes[i], v)\
                        for i in range(nx)]
                        
            x_axes = [domx[0] + i*dx for i in range(nx)]
            
            analitic = [analitic_boundary_layer_equation(x_axes[i], v)\
                        for i in range(nx)]
            
            numeric = solver.advection_difusion_equation_solver(nx, domx, domt, cfl, v,\
                                           initial_cond_func,\
                                           initial_cond_func(domx[0]),\
                                           1.0,\
                                           SCHEME, param,\
                                           None,\
                                           SCHEME_LABEL, marker = marker,\
                                           PATH = custom_path,\
                                           equation_type = solver.Equation_types.Boundary_layer,\
                                           a = 1,\
                                           save_step_by_step = False, clean_plot = False,\
                                           ymin = ymin, ymax = ymax,
                                           customFileName = fileName,
                                           customTitle = title,
                                           outsideLegend=True)
            
            e1 = calculateError(analitic, numeric, nx, tipo = 1)
            e2 = calculateError(analitic, numeric, nx, tipo = 2)
            e3 = calculateError(analitic, numeric, nx, tipo = 3)
            
            e1_vet.append(e1)
            e2_vet.append(e2)
            e3_vet.append(e3)
            
            h_vet.append(dx)
            
            if index>0:
                
                o1=((np.log(e1_vet[index]) - np.log(e1_vet[index-1]))\
                              /(np.log(h_vet[index]) - np.log(h_vet[index-1])))
                
                o2=((np.log(e2_vet[index]) - np.log(e2_vet[index-1]))\
                              /(np.log(h_vet[index]) - np.log(h_vet[index-1])))
                
                o3=((np.log(e3_vet[index]) - np.log(e3_vet[index-1]))\
                              /(np.log(h_vet[index]) - np.log(h_vet[index-1])))
                
                print(str(nx) +\
                  "       "+ str(time_string.format(e1)) +"       "+ str(time_string.format(o1)) +\
                  "       "+ str(time_string.format(e2)) + "       "+ str(time_string.format(o2)) +\
                  "       "+ str(time_string.format(e3)) + "       "+ str(time_string.format(o3)))
            else:
                
                o1 = '-----'
                o2 = '-----'
                o3 = '-----'
                
                print(str(nx) +\
                  "       "+ str(time_string.format(e1)) + "       " + o1 +\
                  "       "+ str(time_string.format(e2)) + "       " + o2 +\
                  "       "+ str(time_string.format(e3)) + "       " + o3)
            
            index = index + 1;

schemes_comparation_boundary_layer_equation_test()















